#
# Cookbook:: testfile
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

file '/tmp/cheffile.txt' do
	action :create
	content 'Chef example file'
end